package dk.sdu.dm847.exam.task1;

/**
 * Peak object.
 * This represents a single peak in the peak alignment process.
 */
public class Peak {
    private final String measurementName;
    private final String peakName;
    private final double t;
    private final double r;
    private final double signal;
    private final int indexT;
    private final int indexR;
    private int uniqueId = -1;

    public Peak(String measurementName, String peakName, double t, double r, double signal, int indexT, int indexR) {
        this.measurementName = measurementName;
        this.peakName = peakName;
        this.t = t;
        this.r = r;
        this.signal = signal;
        this.indexT = indexT;
        this.indexR = indexR;
    }

    public double distanceTo(Peak other) {
        return Math.sqrt(Math.pow(other.getT() - t, 2) + Math.pow(other.getR() - r, 2));
    }

    public String getMeasurementName() {
        return measurementName;
    }

    public String getPeakName() {
        return peakName;
    }

    public double getT() {
        return t;
    }

    public double getR() {
        return r;
    }

    public double getSignal() {
        return signal;
    }

    public int getIndexT() {
        return indexT;
    }

    public int getIndexR() {
        return indexR;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Peak peak = (Peak) o;

        if (Double.compare(peak.t, t) != 0) return false;
        if (Double.compare(peak.r, r) != 0) return false;
        if (Double.compare(peak.signal, signal) != 0) return false;
        if (indexT != peak.indexT) return false;
        if (indexR != peak.indexR) return false;
        if (uniqueId != peak.uniqueId) return false;
        if (!measurementName.equals(peak.measurementName)) return false;
        return peakName.equals(peak.peakName);

    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = measurementName.hashCode();
        result = 31 * result + peakName.hashCode();
        temp = Double.doubleToLongBits(t);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(r);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(signal);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + indexT;
        result = 31 * result + indexR;
        result = 31 * result + uniqueId;
        return result;
    }

    @Override
    public String toString() {
        return "Peak{" +
                "measurementName='" + measurementName + '\'' +
                ", peakName='" + peakName + '\'' +
                ", t=" + t +
                ", r=" + r +
                ", signal=" + signal +
                ", indexT=" + indexT +
                ", indexR=" + indexR +
                '}';
    }

    public int getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(int uniqueId) {
        this.uniqueId = uniqueId;
    }
}
